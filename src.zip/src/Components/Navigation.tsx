import React from "react";
import ReactDOM from "react-dom";
import "./Nav.css";

type Props = {};
const Navigation = (props: Props) => {
  return (
   
   <div className="nav">
     <h2>EMPLOYEE MANAGEMENT SYSTEM</h2>
    </div>
  );
};
export default Navigation;
